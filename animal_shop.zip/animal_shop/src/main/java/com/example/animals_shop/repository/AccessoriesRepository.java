package com.example.animals_shop.repository;

import com.example.animals_shop.model.Accessories;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccessoriesRepository extends JpaRepository<Accessories, Integer> {
}
