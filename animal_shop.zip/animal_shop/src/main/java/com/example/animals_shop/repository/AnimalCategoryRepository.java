package com.example.animals_shop.repository;

import com.example.animals_shop.model.AnimalCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnimalCategoryRepository extends JpaRepository<AnimalCategory, Integer> {
}
