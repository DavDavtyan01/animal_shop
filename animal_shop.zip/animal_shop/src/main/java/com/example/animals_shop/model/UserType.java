package com.example.animals_shop.model;

public enum UserType {
    ADMIN, USER
}
