package com.example.animals_shop.repository;

import com.example.animals_shop.model.Animal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface AnimalRepository extends JpaRepository<Animal, Integer> {

//    @Modifying
//    @Transactional
//    @Query(value = "DELETE FROM admin_animal WHERE admin_id = :adminId AND animal_id = :fromId", nativeQuery = true)
//    void deleteAnimalById(@Param("adminId") int id, @Param("fromId") int fromId);

    void deleteById(int id);


}
