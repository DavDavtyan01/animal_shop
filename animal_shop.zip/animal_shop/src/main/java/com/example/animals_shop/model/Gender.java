package com.example.animals_shop.model;

public enum Gender {
    MALE,FEMALE
}
