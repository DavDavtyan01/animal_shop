package com.example.animals_shop.controller;

import com.example.animals_shop.repository.AccessoriesCategoryRepository;
import com.example.animals_shop.repository.AnimalCategoryRepository;
import com.example.animals_shop.repository.AnimalRepository;
import com.example.animals_shop.repository.FeedCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

    @Autowired
    private AnimalRepository animalRepository;

    @Autowired
    private AnimalCategoryRepository animalCategoryRepository;

    @Autowired
    private AccessoriesCategoryRepository accessoriesCategoryRepository;

    @Autowired
    private FeedCategoryRepository feedCategoryRepository;

    @GetMapping("/admin")
    public String adminPage(ModelMap map){

        map.addAttribute("animalCategories", animalCategoryRepository.findAll());
        map.addAttribute("accessoriesCategories", accessoriesCategoryRepository.findAll());
        map.addAttribute("feedCategories", feedCategoryRepository.findAll());
        map.addAttribute("animals", animalRepository.findAll());
        return "addAnimal";
    }

}
